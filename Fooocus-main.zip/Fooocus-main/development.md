## Running unit tests

Native python:
```
python -m unittest tests/
```

Embedded python (Windows zip file installation method):
```
..\python_embeded\python.exe -m unittest
```
